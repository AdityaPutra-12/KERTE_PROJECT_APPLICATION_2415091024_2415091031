lucide.createIcons();

const mobileMenuButton = document.getElementById('mobile-menu-button');
const mobileMenu = document.getElementById('mobile-menu');
mobileMenuButton.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
    const menuIcon = mobileMenuButton.querySelector('i');
    if (mobileMenu.classList.contains('hidden')) {
        menuIcon.setAttribute('data-lucide', 'menu');
    } else {
        menuIcon.setAttribute('data-lucide', 'x');
    }
    lucide.createIcons();
});
mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
        mobileMenu.classList.add('hidden');
        mobileMenuButton.querySelector('i').setAttribute('data-lucide', 'menu');
        lucide.createIcons();
    });
});

const dataset = [
    { id: 1, nama_kerajinan: "Sokasi", jenis_kerajinan: "Perlengkapan Upacara", deskripsi_kerajinan: "Wadah anyaman ate yang rapat berbentuk kotak dengan tutup kotak di atas wadahnya, seringkali memiliki berbagai macam motif yang khas. Digunakan untuk membawa persembahan suci.", fungsi_kerajinan: "Wadah banten/sesajen.", harga: "Sedang", gambar_url: "Asset_Gambar/SokasiKotak.jpg", pengrajin: { nama: "Ni Wayan Sari", kategori_pengrajin: "Penganyam Senior", rentang_usia: "50-60", keterangan_pengrajin: "Mewarisi keahlian menganyam dari ibunya, spesialis motif geometris Bali." }, bahan_baku: [ { nama_bahan: "Ate Pilihan", jenis_bahan: "Serat Alam", asal_bahan: "Desa Tenganan, Karangasem", karakteristik: "Sangat lentur dan kuat, menghasilkan anyaman yang rapat dan tahan lama." }, { nama_bahan: "Bambu Tali", jenis_bahan: "Bambu", asal_bahan: "Lokal", karakteristik: "Digunakan sebagai kerangka utama sokasi agar kokoh." } ], tahapan_pembuatan: [ { tahapan: 1, proses: "Pengeringan dan Pembelahan Ate", waktu: "1 Minggu", tingkat_kesulitan: "Sedang" }, { tahapan: 2, proses: "Pembuatan Kerangka Bambu", waktu: "2 Hari", tingkat_kesulitan: "Sedang" }, { tahapan: 3, proses: "Proses Menganyam Badan Sokasi", waktu: "5 Hari", tingkat_kesulitan: "Sulit" }, { tahapan: 4, proses: "Pengasapan (Finishing)", waktu: "1 Hari", tingkat_kesulitan: "Mudah" } ], alat: [ { nama_alat: "Pengetam", fungsi_alat: "Untuk membelah dan menipiskan batang ate." }, { nama_alat: "Jarum Anyam", fungsi_alat: "Membantu merapikan dan mengunci anyaman." } ] },
    { id: 2, nama_kerajinan: "Bokor", jenis_kerajinan: "Perlengkapan Upacara", deskripsi_kerajinan: "Wadah dari anyaman ate yang dipakai dalam tradisi Bali, terutama untuk upacara keagamaan (upakara) dan kegiatan sehari-hari.", fungsi_kerajinan: "Untuk menaruh bunga, sesaji, atau perlengkapan upacara lainnya.", harga: "Rendah", gambar_url: "Asset_Gambar/Bokor.jpg", pengrajin: { nama: "Ibu Kadek", kategori_pengrajin: "Penganyam Ate", rentang_usia: "30-40", keterangan_pengrajin: "Spesialis dalam anyaman ate ukuran kecil dengan detail yang presisi." }, bahan_baku: [ { nama_bahan: "Tanaman Ate", jenis_bahan: "Serat Alam", asal_bahan: "Karangasem, Bali", karakteristik: "Lentur, kuat, dan tahan lama setelah dikeringkan." } ], tahapan_pembuatan: [ { tahapan: 1, proses: "Pengeringan Batang Ate", waktu: "1 Minggu", tingkat_kesulitan: "Mudah" }, { tahapan: 2, proses: "Pembelahan dan Penghalusan", waktu: "1 Hari", tingkat_kesulitan: "Sedang" }, { tahapan: 3, proses: "Penganyaman Pola Dasar", waktu: "2 Hari", tingkat_kesulitan: "Sedang" } ], alat: [ { nama_alat: "Pengetam Bambu", fungsi_alat: "Untuk membelah dan menipiskan batang ate." }, { nama_alat: "Jarum", fungsi_alat: "Membantu merapikan ujung anyaman." } ] },
    { id: 3, nama_kerajinan: "Tas Selempang Kotak", jenis_kerajinan: "Aksesoris Fashion", deskripsi_kerajinan: "Tas selempang berbentuk bulat yang ikonik, sering disebut 'Tas Rotan Bali'. Bagian dalamnya dilapisi kain batik.", fungsi_kerajinan: "Tas untuk bepergian, pelengkap busana kasual.", harga: "Tinggi", gambar_url: "Asset_Gambar/TasKotak.jpg", pengrajin: { nama: "Kelompok Pengrajin Wanita Sari", kategori_pengrajin: "Penganyam Tas", rentang_usia: "25-50", keterangan_pengrajin: "Kelompok usaha yang memproduksi tas ate untuk pasar ekspor." }, bahan_baku: [ { nama_bahan: "Ate Pilihan", jenis_bahan: "Serat Alam", asal_bahan: "Lokal", karakteristik: "Kuat dan dapat dibentuk menjadi kotak persegi dengan sedikit lekukan pada sisi tas." }, { nama_bahan: "Kain Batik", jenis_bahan: "Tekstil", asal_bahan: "Jawa", karakteristik: "Sebagai lapisan dalam (lining) dengan motif yang beragam." }, { nama_bahan: "Tali Kulit Sintetis", jenis_bahan: "Sintetis", asal_bahan: "Impor", karakteristik: "Sebagai tali selempang yang kuat dan nyaman." } ], tahapan_pembuatan: [ { tahapan: 1, proses: "Pembuatan Dua Sisi Kotak Tas", waktu: "4 Hari", tingkat_kesulitan: "Sulit" }, { tahapan: 2, proses: "Penggabungan dan Pembuatan Engsel", waktu: "2 Hari", tingkat_kesulitan: "Sulit" }, { tahapan: 3, proses: "Pemasangan Lapisan Kain dan Tali", waktu: "1 Hari", tingkat_kesulitan: "Sedang" }, { tahapan: 4, proses: "Pengasapan dan Penjemuran", waktu: "2 Hari", tingkat_kesulitan: "Mudah" } ], alat: [ { nama_alat: "Cetakan Kayu Kotak", fungsi_alat: "Untuk membentuk anyaman agar bulat sempurna." }, { nama_alat: "Jarum dan Benang", fungsi_alat: "Untuk menjahit lapisan kain batik." } ] },
    { id: 4, nama_kerajinan: "Keben", jenis_kerajinan: "Perlengkapan Upacara", deskripsi_kerajinan: "Wadah anyaman ate yang rapat berbentuk bundar atau melingkar dengan tutup bundar di atas wadahnya, dan keben biasanya memiliki berbagai macam motif yang khas. Digunakan untuk membawa persembahan suci.", fungsi_kerajinan: "Wadah banten/sesajen.", harga: "Sedang", gambar_url: "Asset_Gambar/Keben.jpg", pengrajin: { nama: "Ni Wayan Sari", kategori_pengrajin: "Penganyam Senior", rentang_usia: "50-60", keterangan_pengrajin: "Mewarisi keahlian menganyam dari ibunya, spesialis motif bunga Bali." }, bahan_baku: [ { nama_bahan: "Ate Pilihan", jenis_bahan: "Serat Alam", asal_bahan: "Desa Tenganan, Karangasem", karakteristik: "Sangat lentur dan kuat, menghasilkan anyaman yang rapat dan tahan lama." }, { nama_bahan: "Bambu Tali", jenis_bahan: "Bambu", asal_bahan: "Lokal", karakteristik: "Digunakan sebagai kerangka utama sokasi agar kokoh." } ], tahapan_pembuatan: [ { tahapan: 1, proses: "Pengeringan dan Pembelahan Ate", waktu: "1 Minggu", tingkat_kesulitan: "Sedang" }, { tahapan: 2, proses: "Pembuatan Kerangka Bambu", waktu: "2 Hari", tingkat_kesulitan: "Sedang" }, { tahapan: 3, proses: "Proses Menganyam Badan Sokasi", waktu: "5 Hari", tingkat_kesulitan: "Sulit" }, { tahapan: 4, proses: "Pengasapan (Finishing)", waktu: "1 Hari", tingkat_kesulitan: "Mudah" } ], alat: [ { nama_alat: "Pengetam", fungsi_alat: "Untuk membelah dan menipiskan batang ate." }, { nama_alat: "Jarum Anyam", fungsi_alat: "Membantu merapikan dan mengunci anyaman." } ] },
    { id: 5, nama_kerajinan: "Kotak Tisu", jenis_kerajinan: "Perlengkapan Rumah Tangga", deskripsi_kerajinan: "Wadah anyaman ate berbentuk persegi panjang dengan lubang di tengah-tengah anyamannya yang berbentuk persegi panjang atau horizontal, dengan motif batik pada pinggir-pinggir lubangnya.", fungsi_kerajinan: "Wadah menyimpan tisu", harga: "Rendah", gambar_url: "Asset_Gambar/KotakTisu.jpg", pengrajin: { nama: "Ni Made Suryani", kategori_pengrajin: "Penganyam Junior", rentang_usia: "35-55", keterangan_pengrajin: "Mewarisi keahlian menganyam dari ibunya, spesialis motif bebatikan Bali." }, bahan_baku: [ { nama_bahan: "Ate Pilihan", jenis_bahan: "Serat Alam", asal_bahan: "Desa Tenganan, Karangasem", karakteristik: "Sangat lentur dan kuat, menghasilkan anyaman yang rapat dan tahan lama." }, { nama_bahan: "Bambu Tali", jenis_bahan: "Bambu", asal_bahan: "Lokal", karakteristik: "Digunakan sebagai kerangka utama sokasi agar kokoh." } ], tahapan_pembuatan: [ { tahapan: 1, proses: "Pengeringan dan Pembelahan Ate", waktu: "1 Minggu", tingkat_kesulitan: "Sedang" }, { tahapan: 2, proses: "Pembuatan Kerangka Bambu", waktu: "2 Hari", tingkat_kesulitan: "Sedang" }, { tahapan: 3, proses: "Proses Menganyam Badan Sokasi", waktu: "5 Hari", tingkat_kesulitan: "Sulit" }, { tahapan: 4, proses: "Pengasapan (Finishing)", waktu: "1 Hari", tingkat_kesulitan: "Mudah" } ], alat: [ { nama_alat: "Pengetam", fungsi_alat: "Untuk membelah dan menipiskan batang ate." }, { nama_alat: "Jarum Anyam", fungsi_alat: "Membantu merapikan dan mengunci anyaman." } ] },
    { id: 6, nama_kerajinan: "Tas Jinjing", jenis_kerajinan: "Aksesoris Fashion", deskripsi_kerajinan: "Tas tangan berbentuk bulat yang terbuat dari anyaman ate. Tas ini memiliki pegangan yang nyaman untuk dijinjing dan biasa dilengkapi dengan lapisan kain di bagian dalam, cocok digunakan di berbagai acara.", fungsi_kerajinan: "Wadah menyimpan barang atau keperluan fashion.", harga: "Tinggi", gambar_url: "Asset_Gambar/TasBundar.jpg", pengrajin: { nama: "Ni Made Mustika", kategori_pengrajin: "Penganyam Senior", rentang_usia: "50-60", keterangan_pengrajin: "Mewarisi keahlian menganyam dari ibunya, spesialis motif geometris Bali." }, bahan_baku: [ { nama_bahan: "Ate Pilihan", jenis_bahan: "Serat Alam", asal_bahan: "Desa Tenganan, Karangasem", karakteristik: "Sangat lentur dan kuat, menghasilkan anyaman yang rapat dan tahan lama." }, { nama_bahan: "Bambu Tali", jenis_bahan: "Bambu", asal_bahan: "Lokal", karakteristik: "Digunakan sebagai kerangka utama sokasi agar kokoh." } ], tahapan_pembuatan: [ { tahapan: 1, proses: "Pengeringan dan Pembelahan Ate", waktu: "1 Minggu", tingkat_kesulitan: "Sedang" }, { tahapan: 2, proses: "Pembuatan Kerangka Bambu", waktu: "2 Hari", tingkat_kesulitan: "Sedang" }, { tahapan: 3, proses: "Proses Menganyam Badan Sokasi", waktu: "5 Hari", tingkat_kesulitan: "Sulit" }, { tahapan: 4, proses: "Pengasapan (Finishing)", waktu: "1 Hari", tingkat_kesulitan: "Mudah" } ], alat: [ { nama_alat: "Pengetam", fungsi_alat: "Untuk membelah dan menipiskan batang ate." }, { nama_alat: "Jarum Anyam", fungsi_alat: "Membantu merapikan dan mengunci anyaman." } ] },
    { id: 7, nama_kerajinan: "Keranjang", jenis_kerajinan: "Perlengkapan Rumah Tangga", deskripsi_kerajinan: "Wadah anyaman ate yang rapat dengan tutup, dan berbentuk bundar/tabung, biasa digunakan untuk menyimpan aksesoris, menyimpan pakaian atau barang rumah tangga lainnya", fungsi_kerajinan: "Wadah untuk menyimpan berbagai macam barang terutama pakaian", harga: "Tinggi", gambar_url: "Asset_Gambar/Keranjang.jpg", pengrajin: { nama: "Ni Wayan Sari", kategori_pengrajin: "Penganyam Senior", rentang_usia: "50-60", keterangan_pengrajin: "Mewarisi keahlian menganyam dari ibunya, spesialis motif geometris Bali." }, bahan_baku: [ { nama_bahan: "Ate Pilihan", jenis_bahan: "Serat Alam", asal_bahan: "Desa Tenganan, Karangasem", karakteristik: "Sangat lentur dan kuat, menghasilkan anyaman yang rapat dan tahan lama." }, { nama_bahan: "Bambu Tali", jenis_bahan: "Bambu", asal_bahan: "Lokal", karakteristik: "Digunakan sebagai kerangka utama sokasi agar kokoh." } ], tahapan_pembuatan: [ { tahapan: 1, proses: "Pengeringan dan Pembelahan Ate", waktu: "1 Minggu", tingkat_kesulitan: "Sedang" }, { tahapan: 2, proses: "Pembuatan Kerangka Bambu", waktu: "2 Hari", tingkat_kesulitan: "Sedang" }, { tahapan: 3, proses: "Proses Menganyam Badan Sokasi", waktu: "5 Hari", tingkat_kesulitan: "Sulit" }, { tahapan: 4, proses: "Pengasapan (Finishing)", waktu: "1 Hari", tingkat_kesulitan: "Mudah" } ], alat: [ { nama_alat: "Pengetam", fungsi_alat: "Untuk membelah dan menipiskan batang ate." }, { nama_alat: "Jarum Anyam", fungsi_alat: "Membantu merapikan dan mengunci anyaman." } ] },
    { id: 8, nama_kerajinan: "Nampan", jenis_kerajinan: "Perlengkapan Rumah Tangga", deskripsi_kerajinan: "Wadah anyaman ate berbentuk oval bergelombang (terdapat lekukan-lekukan khusus di tiap sisinya), biasanya sering digunakan untuk menyajikan makanan dan minuman di hotel ataupun restoran, juga dapat digunakan sebagai hiasan serbaguna yang memberi nuansa Bali klasik.", fungsi_kerajinan: "Wadah untuk menaruh makanan dan minuman", harga: "Rendah", gambar_url: "Asset_Gambar/Nampan.jpg", pengrajin: { nama: "Ni Wayan Sari", kategori_pengrajin: "Penganyam Senior", rentang_usia: "50-60", keterangan_pengrajin: "Mewarisi keahlian menganyam dari ibunya, spesialis motif geometris Bali." }, bahan_baku: [ { nama_bahan: "Ate Pilihan", jenis_bahan: "Serat Alam", asal_bahan: "Desa Tenganan, Karangasem", karakteristik: "Sangat lentur dan kuat, menghasilkan anyaman yang rapat dan tahan lama." }, { nama_bahan: "Bambu Tali", jenis_bahan: "Bambu", asal_bahan: "Lokal", karakteristik: "Digunakan sebagai kerangka utama sokasi agar kokoh." } ], tahapan_pembuatan: [ { tahapan: 1, proses: "Pengeringan dan Pembelahan Ate", waktu: "1 Minggu", tingkat_kesulitan: "Sedang" }, { tahapan: 2, proses: "Pembuatan Kerangka Bambu", waktu: "2 Hari", tingkat_kesulitan: "Sedang" }, { tahapan: 3, proses: "Proses Menganyam Badan Sokasi", waktu: "5 Hari", tingkat_kesulitan: "Sulit" }, { tahapan: 4, proses: "Pengasapan (Finishing)", waktu: "1 Hari", tingkat_kesulitan: "Mudah" } ], alat: [ { nama_alat: "Pengetam", fungsi_alat: "Untuk membelah dan menipiskan batang ate." }, { nama_alat: "Jarum Anyam", fungsi_alat: "Membantu merapikan dan mengunci anyaman." } ] },
];
const galleryContainer = document.getElementById('gallery-container');
const searchInput = document.getElementById('search-input');
const noResultsDiv = document.getElementById('no-results');
const detailModal = document.getElementById('detail-modal');
const modalContentWrapper = document.getElementById('modal-content-wrapper');
const showTriviaDetailButton = document.getElementById('show-trivia-detail');
const triviaDetailModal = document.getElementById('trivia-detail-modal');
const closeTriviaModalButton = document.getElementById('close-trivia-modal');
const showVideoModalBtn = document.getElementById('show-video-modal-btn');
const videoModal = document.getElementById('video-modal');
const closeVideoModalButton = document.getElementById('close-video-modal');
const youtubeVideoPlayer = document.getElementById('youtube-video-player');
const youtubeLink = document.getElementById('youtube-link');

function getPriceBadge(harga) {
    let badgeClass = '';
    switch (harga) {
        case 'Rendah': badgeClass = 'bg-green-100 text-green-800'; break;
        case 'Sedang': badgeClass = 'bg-blue-100 text-blue-800'; break;
        case 'Tinggi': badgeClass = 'bg-indigo-100 text-indigo-800'; break;
        default: badgeClass = 'bg-gray-100 text-gray-800';
    }
    return `<span class="price-badge ${badgeClass}">Kategori Harga: ${harga}</span>`;
}

function renderGallery(items) {
    galleryContainer.innerHTML = '';
    if (items.length === 0) {
        noResultsDiv.classList.remove('hidden');
    } else {
        noResultsDiv.classList.add('hidden');
    }
    items.forEach(item => {
        const card = document.createElement('div');
        card.className = 'card cursor-pointer flex flex-col';
        card.dataset.id = item.id;
        card.innerHTML = `
            <div class="card-image-container">
                <img src="${item.gambar_url}" alt="${item.nama_kerajinan}">
            </div>
            <div class="p-4 flex-grow">
                <h3 class="font-semibold text-lg text-slate-800 truncate">${item.nama_kerajinan}</h3>
                <p class="text-sm text-slate-500">${item.jenis_kerajinan}</p>
                <div class="mt-2">${getPriceBadge(item.harga)}</div>
            </div>
        `;
        card.addEventListener('click', () => showDetailModal(item.id));
        galleryContainer.appendChild(card);
    });
}

function showDetailModal(id) {
    const item = dataset.find(d => d.id === id);
    if (!item) return;
    modalContentWrapper.innerHTML = `
        <div class="flex justify-between items-start">
            <h2 class="text-3xl font-bold title-font mb-4 text-slate-900">${item.nama_kerajinan}</h2>
            <button id="close-detail-modal" class="text-slate-500 hover:text-slate-800">
                <i data-lucide="x" class="h-8 w-8"></i>
            </button>
        </div>
        <div class="grid md:grid-cols-2 gap-8">
            <div>
                <div class="modal-image-container">
                   <img src="${item.gambar_url}" alt="${item.nama_kerajinan}">
                </div>
                <div class="detail-section">
                    <h3>Deskripsi & Fungsi</h3>
                    <p class="text-slate-600">${item.deskripsi_kerajinan}</p>
                    <p class="mt-2 text-slate-600"><strong>Fungsi:</strong> ${item.fungsi_kerajinan}</p>
                    <div class="mt-4">${getPriceBadge(item.harga)}</div>
                </div>
            </div>
            <div class="space-y-6">
                <div class="detail-section">
                    <h3>Profil Pengrajin</h3>
                    <p class="font-semibold text-slate-700">${item.pengrajin.nama} (${item.pengrajin.kategori_pengrajin})</p>
                    <p class="text-sm text-slate-500">Usia: ${item.pengrajin.rentang_usia}</p>
                    <p class="text-sm text-slate-600 mt-1">${item.pengrajin.keterangan_pengrajin}</p>
                </div>
                <div class="detail-section">
                    <h3>Bahan Baku Utama</h3>
                    <ul class="space-y-3 text-slate-600">
                        ${item.bahan_baku.map(b => `
                            <li>
                                <strong class="block text-slate-700">${b.nama_bahan} (${b.jenis_bahan})</strong>
                                <span class="text-sm">${b.karakteristik} (Asal: ${b.asal_bahan})</span>
                            </li>`).join('')}
                    </ul>
                </div>
                <div class="detail-section">
                    <h3>Alat yang Digunakan</h3>
                     <ul class="space-y-3 text-slate-600">
                        ${item.alat.map(a => `
                            <li>
                                <strong class="block text-slate-700">${a.nama_alat}</strong>
                                <span class="text-sm">${a.fungsi_alat}</span>
                            </li>`).join('')}
                    </ul>
                </div>
            </div>
        </div>
        <div class="detail-section mt-8">
            <h3>Proses Pembuatan</h3>
            <ol class="relative border-l border-slate-200 mt-4">
                ${item.tahapan_pembuatan.map(t => `
                <li class="mb-6 ml-6">
                    <span class="absolute flex items-center justify-center w-6 h-6 bg-indigo-100 rounded-full -left-3 ring-8 ring-white">
                        <i data-lucide="git-commit" class="w-4 h-4 text-indigo-600"></i>
                    </span>
                    <h4 class="flex items-center mb-1 text-lg font-semibold text-slate-900">${t.proses}</h4>
                    <time class="block mb-2 text-sm font-normal leading-none text-slate-400">Estimasi: ${t.waktu} | Tingkat Kesulitan: ${t.tingkat_kesulitan}</time>
                </li>
                `).join('')}
            </ol>
        </div>
    `;
    detailModal.classList.add('active');
    lucide.createIcons();
    document.getElementById('close-detail-modal').addEventListener('click', () => {
        detailModal.classList.remove('active');
    });
}

searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filteredData = dataset.filter(item => 
        item.nama_kerajinan.toLowerCase().includes(searchTerm) ||
        item.jenis_kerajinan.toLowerCase().includes(searchTerm)
    );
    renderGallery(filteredData);
});

detailModal.addEventListener('click', (e) => {
    if (e.target === detailModal) {
        detailModal.classList.remove('active');
    }
});

document.addEventListener('keydown', (e) => {
    if (e.key === "Escape" && detailModal.classList.contains('active')) {
        detailModal.classList.remove('active');
    }
});

showTriviaDetailButton.addEventListener('click', () => {
    triviaDetailModal.classList.add('active');
    lucide.createIcons();
});

closeTriviaModalButton.addEventListener('click', () => {
    triviaDetailModal.classList.remove('active');
});

triviaDetailModal.addEventListener('click', (e) => {
    if (e.target === triviaDetailModal) {
        triviaDetailModal.classList.remove('active');
    }
});

function getYoutubeVideoId(url) {
    const regExp = /^.*(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/;
    const match = url.match(regExp);
    if (match) {
         const videoIdMatch = url.match(/(?<=v=|\/)([a-zA-Z0-9_-]{11})(?=&|#|$)/);
         return videoIdMatch ? videoIdMatch[0] : null;
    }
    return null;
}

showVideoModalBtn.addEventListener('click', () => {
    const youtubeUrl = youtubeLink.href;
    const videoId = getYoutubeVideoId(youtubeUrl);
    if (videoId) {
        youtubeVideoPlayer.src = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
        videoModal.classList.add('active');
    } else {
        alert('URL YouTube tidak valid.');
    }
});

closeVideoModalButton.addEventListener('click', () => {
    videoModal.classList.remove('active');
    youtubeVideoPlayer.src = '';
});

videoModal.addEventListener('click', (e) => {
    if (e.target === videoModal) {
        videoModal.classList.remove('active');
        youtubeVideoPlayer.src = '';
    }
});
renderGallery(dataset);